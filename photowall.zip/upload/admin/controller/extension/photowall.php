<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-09-23
 * Time: 上午 10:46
 */

class ControllerExtensionPhotowall extends Controller {
    /**
     * 照片墙列表
     */
    public function index() {

        if ($this->request->server['HTTPS']) {
            $data['catalog_image'] = HTTPS_CATALOG . 'image/' ;
        } else {
            $data['catalog_image'] = HTTP_CATALOG . 'image/' ;
        }
        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        }

        $page_limit = $this->config->get('config_limit_admin');


        $this->load->model('extension/photowall');

        $filter = isset($this->request->get['filter']) ? $this->request->get['filter'] : [] ;
        $data['filter'] = $filter;

        $photowalls = $this->model_extension_photowall->getPhotowalls($filter, ($page - 1)*$page_limit, $page_limit);

        $data['user_token'] =  $this->session->data['user_token'];

        $data['edit'] = $this->url->link('extension/photowall/edit', 'user_token=' . $this->session->data['user_token'], true);
        $data['delete'] = $this->url->link('extension/photowall/delete', 'user_token=' . $this->session->data['user_token'], true);


        $data['photowalls'] = $photowalls;
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        /* 分页 */
        $photowall_total = $this->model_extension_photowall->getPhotowallCount($filter);
        $pagination = new Pagination();
        $pagination->total = $photowall_total;
        $pagination->page = $page;
        $pagination->limit = $page_limit;
        $url = '';
        foreach ($filter as $n => $v){
            $url .= '&filter['.$n .']='.urlencode(html_entity_decode($v, ENT_QUOTES, 'UTF-8'));
        }
        $pagination->url = $this->url->link('extension/photowall', 'user_token=' . $this->session->data['user_token'] . $url . '&page={page}', true);
        $data['pagination'] = $pagination->render();


        $data['results'] = sprintf('‌Showing %d to %d of %d (%d Pages)',
            ($photowall_total) ? (($page - 1) * $page_limit) + 1 : 0,
            (($page * $page_limit) > $photowall_total) ? $photowall_total : ($page * $page_limit) ,
            $photowall_total,
            ceil($photowall_total / $page_limit));


        $this->response->setOutput($this->load->view('extension/photowall/list', $data));
    }

    public function edit(){
        $photowall_id = $this->request->get['photowall_id'];
        $this->load->model('extension/photowall');
        $photowall = $this->model_extension_photowall->getPhotowall($photowall_id);

        $error_warning = '';
        if($this->request->post){
            // 数据验证
            $seo_key = trim($this->request->post['seo_key']);
            if(!$seo_key){
                $error_warning = '照片墙seo key  不能为空!';
                goto post_end;
            }
            $photowall_data =  $this->request->post['photowall'];

            if(!$photowall_data['name']){
                $error_warning = '照片墙名称不能为空!';
                goto post_end;
            }

            $photowall_image = [];
            if(!isset($this->request->post['photowall_image'])){
                if($photowall_data['status'] ==='1'){
                    $error_warning = '不能发布无照片的照片墙!';
                    goto post_end;
                }
            }else{
                $photowall_image =  $this->request->post['photowall_image'];
            }

            if(!$this->model_extension_photowall->setProductSeoUrl(
                $photowall_id,
                $seo_key
            )){
                $error_warning = 'seo key 已存在!';
                goto post_end;
            }


            // 判断是否有发布
            if($photowall_data['status'] ==='1' && $photowall['upload_key']){

                $image_url = 'catalog/photowall/'.$seo_key;
                if(is_dir(DIR_IMAGE.$image_url)){
                    $error_warning = $image_url
                        . ' 目录已存在请修改 seo key !';
                    goto post_end;
                }
                if(!mkdir(DIR_IMAGE.$image_url,0777, true)){
                    $error_warning = $image_url
                        . ' 目录创建失败 ,请检查权限!';
                    goto post_end;
                }

                foreach ($photowall_image as $id => $image){
                    if(file_exists($image['image'])){
                        rename($image['image'], DIR_IMAGE .$image_url.'/'.$image['name']);
                        $photowall_image[$id]['image'] = $image_url.'/'.$image['name'];
                    }
                }
                $photowall_data['upload_key'] = '';
            }
            $this->model_extension_photowall->uploadImages($photowall_image);

            $this->model_extension_photowall->update($photowall_id ,$photowall_data);


            $this->response->redirect($this->url->link('extension/photowall', 'user_token=' . $this->session->data['user_token'] , true));
            return;
        }

        post_end:

        $data['seo_key'] = $this->model_extension_photowall->getProductSeoUrl($photowall_id);

        if ($this->request->server['HTTPS']) {
            $data['catalog_image'] = HTTPS_CATALOG . 'image/' ;
        } else {
            $data['catalog_image'] = HTTP_CATALOG . 'image/' ;
        }

        $data['error_warning'] = $error_warning;

        $data['photowall'] = $photowall;

        $data['cancel'] = $this->url->link('extension/photowall', 'user_token=' . $this->session->data['user_token'], true);

        $data['show_image'] = $this->url->link('extension/photowall/image', 'user_token=' . $this->session->data['user_token'], true);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/photowall/edit', $data));

    }

    // 显示未发布图片
    public function image(){
        $url = $this->request->get['url'];
        if(file_exists($url)){
            $image = file_get_contents($url);
            header('Content-type: image/jpg');
            echo $image;
            return;
        }
    }

    public function delete(){
        if(isset($this->request->post['selected'])){
            $this->load->model('extension/photowall');
            $photowall_ids = $this->request->post['selected'];
            $this->load->model('extension/photowall');
            $this->model_extension_photowall->batchDelete($photowall_ids);
        }
        $this->response->redirect($this->url->link('extension/photowall', 'user_token=' . $this->session->data['user_token'], true));
    }
}