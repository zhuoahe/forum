<?php

$table_sql = 'CREATE TABLE IF NOT EXISTS `'. DB_PREFIX .'photowall` (
  `photowall_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `image` varchar(255)  DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT \'0\',
  `status` tinyint(1) NOT NULL DEFAULT \'0\',
  `comment` text NOT NULL,
  `ip` varchar(20) NOT NULL,
  `country`varchar(255) NOT NULL,
  `uploader` varchar(255) NOT NULL,
  `user_agent` varchar(255) NOT NULL,
  `meta_title` varchar(255)  NULL,
  `meta_description` varchar(255)  NULL,
  `meta_keyword` varchar(255)  NULL,
  `mail` varchar(255) NOT NULL,
  `product_ids` varchar(255) DEFAULT NULL,
  `upload_date`  date NOT NULL DEFAULT \'0000-00-00\',
  `upload_key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`photowall_id`)
) DEFAULT COLLATE=utf8_general_ci;';
$this->db->query($table_sql);
$table_sql = 'CREATE TABLE IF NOT EXISTS `'. DB_PREFIX .'photowall_image` (
  `photowall_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `photowall_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(3) NOT NULL DEFAULT \'0\',
  `alt` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT \'\',
  PRIMARY KEY (`photowall_image_id`)
)DEFAULT COLLATE=utf8_general_ci;';
$this->db->query($table_sql);


$this->load->model('setting/setting');
$this->load->model('user/user_group');
$this->load->model('design/layout');

$this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/photowall');
$this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/photowall');

/*
$easy_blog_settings = array(
    'easy_blog_global_article_limit' => '10',
    'easy_blog_home_page_meta_title' => 'Blog',
    'easy_blog_home_page_name' => 'Blog',
    'easy_blog_home_page_meta_description' => '',
    'easy_blog_home_page_meta_keyword' => '',
    'easy_blog_global_status' => '1'
);
$this->model_setting_setting->editSetting('easy_blog', $easy_blog_settings, 0);

$query = $this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "layout WHERE name LIKE 'Easy Blog'");

if ($query->row['total'] == 0) {
    $easy_blog_layout = array(
        'name' => 'Easy Blog',
        'layout_route' => array(
            'first_route' => array(
                'store_id' => '0',
                'route' => 'extension/extension/blog/%'
            )
        )
    );
    $this->model_design_layout->addLayout($easy_blog_layout);
}*/

// seo url 用 Gallery

$sql = "select seo_url_id from `". DB_PREFIX . "seo_url` where query='extension/photowall' and keyword='gallery'";
$query = $this->db->query($sql);
if($query->num_rows == 0){
    $sql = "insert into `". DB_PREFIX . "seo_url` ( `keyword`, `query`, `store_id`, `language_id`) values ( 'gallery', 'extension/photowall', '0', '1');";
    $query = $this->db->query($sql);
    $sql = "insert into `". DB_PREFIX . "seo_url` ( `keyword`, `query`, `store_id`, `language_id`) values ( 'gallery-upload', 'extension/photowall/upload', '0', '1');";
    $query = $this->db->query($sql);
}