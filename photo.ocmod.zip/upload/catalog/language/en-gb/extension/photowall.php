<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-09-26
 * Time: 上午 10:03
 */

$_['err_upload_size']   = 'File "%s" (<b>%s KB</b>) exceeds maximum allowed upload size of <b>%s KB</b>.';
$_['err_upload_type']   = '只能上传图片';
$_['err_upload']        = '上传失败稍后再试';

$_['header_title']      = 'Gallery';

$_['meta_title']        = '';
$_['meta_keyword']      = '';
$_['meta_description']  = '';

$_['meta_upload_title']        = '';
$_['meta_upload_keyword']      = '';
$_['meta_upload_description']  = '';

$_['error_email'] = 'E-Mail address does not appear to be valid!';
$_['error_name']  = 'Please fill in your name.';

