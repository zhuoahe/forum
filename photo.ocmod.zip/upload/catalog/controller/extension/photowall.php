<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-09-21
 * Time: 下午 12:23
 */
class ControllerExtensionPhotowall extends Controller
{

    private $maxPhotoSizeKB = 5*1024; // 5M


    public function index()
    {

        $this->load->language('extension/photowall');

        $this->document->addStyle('catalog/view/javascript/photowall.css');

        $data = [];

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('header_title'),
            'href' => $this->url->link('extension/photowall')
        );


        $url = '';
        if (isset($this->request->get['filter_country'])) {
            $url .= '&filter_country=' . $this->request->get['filter_country'];
            $option['filter_country']  = $this->request->get['filter_country'];
        }

        if (isset($this->request->get['filter_product'])) {
            $url .= '&filter_product=' . $this->request->get['filter_product'];
            $option['filter_product']  = $this->request->get['filter_product'];

        }






        if (isset($this->request->get['page'])) {
            $page = $this->request->get['page'];
        } else {
            $page = 1;
        };
        $limit = 2;

        $option['start'] = ($page-1)*$limit;
        $option['limit'] = $limit;
        $this->load->model('extension/photowall');
        $result = $this->model_extension_photowall->getPhotowallAndImages($option);

        $data['photowalls'] = $result['photowalls'];
        $total = $result['count'];

        $pagination = new Pagination();
        $pagination->total = $total;
        $pagination->page = $page;
        $pagination->limit = $limit;
        $pagination->url = $this->url->link('extension/photowall', $url . '&page={page}');

        $data['pagination'] = $pagination->render();

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $data['upload'] = $this->url->link('extension/photowall/upload');





        $view = $this->load->view('extension/photowall/list',$data);
        $this->response->setOutput($view);
    }

    public function content()
    {

        $this->document->addStyle('catalog/view/javascript/photowall.css');


        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );


        $this->load->model('extension/photowall');

        $request = $this->request;
        $photowall_id = $request->get['photowall_id'];

        $photowall = $this->model_extension_photowall->getPhotowall($photowall_id);

        if($photowall){

            $this->load->language('extension/photowall');

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('header_title'),
                'href' => $this->url->link('extension/photowall')
            );

            $this->document->      setTitle($photowall['meta_title']);
            $this->document->setDescription($photowall['meta_description']);
            $this->document->   setKeywords($photowall['meta_keyword']);

            $data['photowall'] = $photowall;
            $view_tpl = 'extension/photowall/content';

        }else{

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_error'),
                'href' => $this->url->link('extension/photowall', 'photowall_id=' . $photowall_id)
            );

            $this->document->setTitle($this->language->get('text_error'));

            $data['heading_title'] = $this->language->get('text_error');

            $data['text_error'] = $this->language->get('text_error');

            $data['button_continue'] = $this->language->get('button_continue');

            $data['continue'] = $this->url->link('common/home');

            $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');


            $view_tpl = 'error/not_found';
        }


        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $view = $this->load->view($view_tpl, $data);

        $this->response->setOutput($view);

    }

    /**
     * ajax upload image
     * @return string
     */
    public function upload()
    {

        $this->load->language('extension/photowall');

        $request = $this->request;
        if ('POST' == $request->server['REQUEST_METHOD']  && $request->files ) {
            $this->upload_file($request);
            return '';
        }

        $this->document->addScript('catalog/view/javascript/bootstrap-fileimput/js/fileinput.min.js');
        $this->document->addStyle('catalog/view/javascript/bootstrap-fileimput/css/fileinput.min.css');

        $this->document->addStyle('catalog/view/javascript/photowall.css');

        $data = [];
        $data['max_photo_size'] = $this->maxPhotoSizeKB;
        $data['uploadUrl'] = $this->url->link('extension/photowall/upload');

        $breadcrumbs = [];
        $breadcrumbs[] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );

        $photowall_url = $this->url->link('extension/photowall');
        $data['photowall_url'] = $photowall_url;
        $breadcrumbs[] = array(
            'text' => $this->language->get('header_title'),
            'href' => $photowall_url
        );
        $breadcrumbs[] = array(
            'text' => 'upload photos',
            'href' => $this->url->link('extension/photowall/upload')
        );

        // 标识同一批上传图片

        $data['breadcrumbs'] = $breadcrumbs;
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $this->response->setOutput($this->load->view('extension/photowall/upload', $data));
    }


    /**
     * 文件上传
     * @param $request
     * @return string
     */
    private function upload_file($request){
        $this->response->addHeader('Content-Type: application/json');
        $json = [
            "data"=>[],
        ];
        $this->load->model('extension/photowall');

        $files = current($request->files);

        $http_status = 400;
        if(!empty($files['name']) && !empty($request->post['upload_time'])){
            $upload_files = [];
            foreach ($files['name'] as $i => $f){

                $temp = $files['tmp_name'][$i];
                $file_size = $files['size'][$i];
                $file_error_code = $files['error'][$i];

                if ($file_size > 1024 * $this->maxPhotoSizeKB || $file_error_code == 1) { //最大图片为5M
                    $json['error'] = sprintf(
                        $this->language->get('err_upload_size'),
                        $f,
                        $this->maxPhotoSizeKB,
                        $this->maxPhotoSizeKB);
                } else if (!$this->model_extension_photowall->isImg($temp)) {
                    $json['error'] = sprintf(
                        $this->language->get('err_upload_type'),
                        $f
                    );
                }else if($file_error_code !=0){
                    /**
                     * 图片上传错误代码.
                     * @link http://php.net/manual/zh/features.file-upload.errors.php
                     */
                    $json['error'] = $this->language->get('err_upload');

                }

                if(!isset($json['error'])) {
                    $upload_file = [
                        'name' => $files['name'][$i],
                        'size' => $file_size,
                        'type' => $files['type'][$i],
                        'tmp_name' => $temp
                    ];
                    $upload_files[] = $upload_file;
                }
            }
            if($upload_files){
                $name    = trim($request->post['name']);
                $mail    = trim($request->post['mail']);
                $comment = htmlentities($request->post['comment']);

                // 同步多个上传.
                //
                //if ($this->model_extension_photowall->uploadPhotoWall($upload_files, $name, $mail, $comment)) {

                // 异步单个上传
                $uploadKey = $this->session->getId() . $request->post['upload_time'];
                if ($this->model_extension_photowall->uploadSingle(current($upload_files), $name, $mail, $comment, $uploadKey)) {
                    $this->response->setOutput(json_encode($json));
                    return '';
                }else{
                    $http_status = 500;
                    $json['error'] = $this->language->get('err_upload');
                }
            }
        } else{
            $json['error'] = $this->language->get('err_upload');
        }

        http_response_code ($http_status);
        $this->response->setOutput(json_encode($json));
    }


}
