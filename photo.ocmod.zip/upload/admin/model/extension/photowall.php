<?php
class ModelExtensionPhotowall extends Model
{

    public function getPhotowalls($filter, $off_set = 0, $limit=20){
        $sql = $this->filterSql($filter);
        $sql .= ' order By upload_date DESC ';
        if($limit){
            $sql .= 'limit ' . $off_set . ',' .$limit;
        }
        $query = $this->db->query($sql);
        return $query->rows;
    }


    public function getPhotowallCount($filter){
        $sql = $this->filterSql($filter, 'count(photowall_id) \'count\'');
        $query = $this->db->query($sql);
        return $query->row['count'];
    }

    private function filterSql( $filter ,$select ='*'){
        $sql = 'select '.$select.' from ' . DB_PREFIX . 'photowall ';
        if(!empty($filter)){
            $sql .= ' where ';
            $where = '';
            foreach ($filter as $k=>$v){
                $where .= 'and '.$k . ' like \'%'.$v.'%\' ';
            }
            $sql .= substr($where, 3);
        }
        return $sql;
    }

    public function getPhotowall($photowall_id){
        $sql = 'select * from ' . DB_PREFIX . 'photowall where photowall_id='.(int)$photowall_id;
        $query = $this->db->query($sql);
        if($query->num_rows==0){
            return null;
        }
        $p =  $query->row;
        $sql =  'select * from ' . DB_PREFIX . 'photowall_image where photowall_id='.(int)$photowall_id;
        $query_image = $this->db->query($sql);
        $p['photowall_image'] = $query_image->rows;
        return $p;
    }

    /**
     * 删除照片墙,包括文件.
     * @param array $ids
     */
    public function batchDelete($ids = []){
        foreach ($ids as $id){
            $p = $this->getPhotowall($id);
            $abPath = '';
            if(!($p['status'] === '0' && $p['upload_key'])){
                // 发布过的
                $abPath = DIR_IMAGE;
            }
            if($p['photowall_image']){
                foreach ($p['photowall_image'] as $image){
                    $filePaht = $abPath . $image['image'];
                    if(file_exists($filePaht)){
                        unlink($filePaht);
                    }
                }
                $dir = dirname($filePaht);
               if($this->emptyDir($dir)){
                   rmdir($dir);
               }
            }
            $this->db->query("delete  FROM " . DB_PREFIX . "seo_url WHERE query = 'photowall_id=" . (int)$id . "'");
        }
        $idStr = implode(',',$ids);
        $this->db->query('delete from '.DB_PREFIX . 'photowall where photowall_id in('.$idStr.')');
        $this->db->query('delete from '.DB_PREFIX . 'photowall_image where photowall_id in('.$idStr.')');

    }

    public function update($id, $option){
        $query = $this->db->query( 'SELECT image from ' . DB_PREFIX .'photowall_image WHERE photowall_id='.(int)$id .' ORDER BY sort_order ');
        if($query->num_rows){
            $option['image'] = $query->row['image'];
        }
        $attr_sql = '';
        foreach($option as $n => $v){
            $attr_sql .= ',' . $n .'=\''. $this->db->escape($v) .'\'';
        }
        $sql = 'update '.DB_PREFIX . 'photowall set '
            . substr($attr_sql,1)
            . ' where photowall_id = '.$id;
        $this->db->query($sql);

    }

    public function uploadImages($images){
        foreach ($images as $id => $image){
            $attr_sql = '';
            foreach($image as $n => $v){
                $attr_sql .= ',' . $n .'=\''. $this->db->escape($v) .'\'';
            }
            $sql = 'update '.DB_PREFIX . 'photowall_image set '
                . substr($attr_sql,1)
                . ' where photowall_image_id = '.$id;
            $this->db->query($sql);
        }
    }

    public  function getProductSeoUrl($photowall_id){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "seo_url WHERE query = 'photowall_id=" . (int)$photowall_id . "'");
        if($query->num_rows){
            return $query->row['keyword'];
        }else{
            return '';
        }
    }

    public function setProductSeoUrl($photowall_id, $seo_key, $store_id=0, $language_id=1){
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX .
            "seo_url WHERE query != 'photowall_id=" . (int)$photowall_id . "' AND keyword='$seo_key' ");
        if($query->num_rows){
            return false;
        }
        $this->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query = 'photowall_id=" . (int)$photowall_id . "'");
        $this->db->query('INSERT INTO ' . DB_PREFIX .'seo_url ( `store_id`, `language_id`, `query`, `keyword`) VALUES ( \''.$store_id.'\', \''.$language_id.'\', \'photowall_id='.$photowall_id.'\', \''.$seo_key.'\')');
             return true;
    }

    /**
     * 判断目录是否为空.
     * @param $directory
     * @return bool
     */
    private  function emptyDir($directory) {
        $handle = opendir($directory);
        while (($file = readdir($handle)) !== false) {
            if ($file !="." && $file != "..") {
                closedir($handle);
                return false;
            }
        }
        closedir($handle);
        return true;
    }
}