# AUTOMATIC INSTALLATION (OCMOD)
-------------------------------------------------------------------------
# ATTENTION: you need OpenCart Extension Installer configured properly and working
-------------------------------------------------------------------------
## Installation
-------------------------------------------------------------------------
* Go to Admin backend:
    0) Install fix for OpenCart 3 Extension Installer 'php_and_sql_in_ext_inst_OC3.ocmod.zip',
    0.1) go to the "Extensions / Modifications" menu and click "Refresh" button,
    1) install extension `easy_blog_simple_vx.y.z.ocmod.zip`,
    2) go to the "Extensions / Modifications" menu and click "Refresh" button,
    3) add new articles (yourstore.com/admin/index.php?route=extension/extension/blog/article),
    4) edit blog configuration (yourstore.com/admin/index.php?route=extension/extension/blog/setting),

Blog on your site: yourstore.com/index.php?route=extension/extension/blog/blog

-------------------------------------------------------------------------
If you had any question about this extension or integration on your website, you can contact with me using e-mail car23an@gmail.com
-------------------------------------------------------------------------
