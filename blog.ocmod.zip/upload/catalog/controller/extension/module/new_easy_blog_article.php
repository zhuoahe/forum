<?php
/**
 * 布局模块显示最新文章.
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-01-26
 * Time: 上午 10:54
 */

class ControllerExtensionModuleNewEasyBlogArticle extends Controller {
    public function index($setting) {
        if (isset($setting['show_count'])) {
            $show_count = $setting['show_count'];
            $this->load->model('extension/extension/blog/article');
            $filter_data['limit'] = $show_count;
            $filter_data['start'] = 0;
            $results = $this->model_extension_extension_blog_article->getArticles($filter_data);
            $data = [];

            foreach ($results as $result) {
                $data['articles'][] = array(
                    'article_id' => $result['article_id'],
                    'name' => $result['name'],
                    'image'=>$result['image'],
                    'date_modified' => date($this->language->get('date_format_short'), strtotime($result['date_modified'])),
                    'intro_text' => html_entity_decode($result['intro_text'], ENT_QUOTES, 'UTF-8'),
                    'href' => $this->url->link('extension/extension/blog/article', 'article_id=' . $result['article_id'])
                );
            }

            return $this->load->view('extension/module/new_easy_blog_article', $data);
        }
    }
}