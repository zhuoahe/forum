<?php
/**
 * 布局模块显示最新文章.
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-01-26
 * Time: 上午 10:54
 */

class ControllerExtensionModuleNewEasyBlogArticle extends Controller {
    public function index($setting) {
        if (isset($setting['show_count'])) {
            $show_count = $setting['show_count'];
            $this->load->model('extension/extension/blog/article');
            $filter_data['limit'] = $show_count;
            $articles = $this->model_extension_extension_blog_article->getArticles($filter_data);
            $data['articles'] = $articles;
            return $this->load->view('extension/module/new_easy_blog_article', $data);
        }
    }
}