<?php
/**
 * 布局模块显示最新文章.
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018-01-26
 * Time: 上午 10:54
 */

$_['heading_title']     = '显示最新blog';
$_['text_edit']         = '编辑';

$_['text_success']      = '保存成功';
$_['entry_status']      = '状态';
$_['entry_name']        = '模块名称';
$_['entry_show_count']  = '显示数量';
$_['error_name']        = '模块名称长度必须大于等于3个字符';
$_['error_permission']  = '没有权限操作';