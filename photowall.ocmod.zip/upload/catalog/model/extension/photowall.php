<?php
// DB_PREFIX

class ModelExtensionPhotowall extends Model
{
    private $upload_photowall_dir = DIR_STORAGE . 'upload/photowall';
    private $baseImgUri ;

    /**
     * 获取网站跟url
     * @return string
     */
    private function getWebsiteUrl(){
        if ($this->request->server['HTTPS']) {
            $uri = HTTPS_SERVER  ;
        } else {
            $uri = HTTP_SERVER ;
        }
        return $uri;
    }

    private function getBaseImgUri(){
        if(!$this->baseImgUri){
            $dir = 'image/';
            $uri = $this->getWebsiteUrl() . $dir ;
            $this->baseImgUri = $uri;
        }
        return $this->baseImgUri;
    }

    /**
     * 获取图片的浏览器地址.
     * @param $img
     * @return string
     */
    private function getImageUrl($img){
        return $this->getBaseImgUri() . $img;
    }

    public function getPhotowall($photowall_id){
        $sql = 'SELECT * from '.DB_PREFIX.'photowall where photowall_id='.$photowall_id;
        $query = $this->db->query($sql);
        if($query->num_rows){
            $photowall = $query->row;
            $photowall['image'] = $this->getImageUrl($photowall['image']);
            $sql = 'SELECT * from '.DB_PREFIX.'photowall_image where photowall_id='.$photowall_id . ' order by sort_order';
            $query = $this->db->query($sql);
            if($query->rows){
                foreach ($query->rows as $i => $row){
                    $query->rows[$i]['image'] = $this->getImageUrl($row['image']);
                }
            }
            $photowall['photowall_images'] = $query->rows;
            if($photowall['product_ids']){
                $sql = 'SELECT * from '.DB_PREFIX.'product where id in ('.$photowall['product_ids'].')';
                $query = $this->db->query($sql);
                $photowall['products'] = $query->rows;
            }
            return $photowall;
        }
        return null;
    }

    public function getPhotowalls($data=[]){
        $reSizeWidth  = 264;
        $reSizeHeight = 264;

        $sql = 'SELECT * from '.DB_PREFIX.'photowall ';


        $whereStr = '';

        if (!empty($data['filter_country'])){
            $whereStr .= "and country = '".$data['filter_country']."' ";
        }
        if( !empty($data['filter_product'])) {
            $whereStr .= "and product_ids = '".$data['filter_product']."' ";
        }
        if($whereStr){
            $whereStr = substr($whereStr, 3);
            $sql .= ' where ' . $whereStr;
        }

        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }


        $query = $this->db->query($sql);
        if($query->num_rows){
            $this->load->model('tool/image');
            foreach ($query->rows as $i =>$row){
                $img = $row['image'];
                // 图片宽缩小到 $reSizeWidth 高度自适应.不失真
                if (is_file(DIR_IMAGE . $img)) {
                    $height = $reSizeHeight;
                    $gSize  = getimagesize(DIR_IMAGE . $img);
                    if($gSize){
                        $width  = $gSize[0];
                        $height = $gSize[1];
                        $height = round($height/$width * $reSizeWidth);
                    }
                    $popup = $this->model_tool_image->resize($img, $reSizeWidth, $height);
                } else {
                    $popup = $this->model_tool_image->resize('no_image.png', $reSizeWidth, $reSizeHeight);
                }
                $query->rows[$i]['popup'] = $popup;
            }
        }
        return $query->rows;

    }



    public function getPhotowallAndImages($data=[]){
        $reSizeWidth  = 290;
        $reSizeHeight = 290;

        $photowallSqlSelect =  'SELECT p.*, i.image \'photowall_image\', i.sort_order, i.alt, s.keyword ';
        $photowallSqlFrom   = 'from `'.DB_PREFIX.'photowall` p '
            . 'LEFT JOIN `'.DB_PREFIX.'photowall_image` i '
            . 'ON p.photowall_id=i.photowall_id ';

        $sql = ' where p.`status`=1 ';
        if (!empty($data['filter_product'])){
            $sql .= "and p.country = '" .  $this->db->escape($data['filter_country']) . "' ";
        }
        if( !empty($data['filter_product'])) {
            $sql .= "and p.product_ids = '" .  $this->db->escape($data['filter_product'])."' ";
        }

        $sql .= 'order by p.photowall_id DESC, i.sort_order ASC ';

        // 获取总数.

        $countSql = 'select count(i.photowall_image_id) \'count\' '.$photowallSqlFrom . $sql;
        $query = $this->db->query($countSql);
        $count = $query->row['count'];


        if (isset($data['start']) || isset($data['limit'])) {
            if ($data['start'] < 0) {
                $data['start'] = 0;
            }

            if ($data['limit'] < 1) {
                $data['limit'] = 20;
            }

            $sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
        }

        $photowallSql = $photowallSqlSelect . $photowallSqlFrom
            . 'LEFT JOIN `'.DB_PREFIX.'seo_url` s '
            . 'ON s.query=concat(\'photowall_id=\', p.photowall_id) '
            . $sql;


        $query = $this->db->query($photowallSql);

        if($query->num_rows){
            $this->load->model('tool/image');
            foreach ($query->rows as $i =>$row){
                $img = $row['photowall_image'];
                // 图片宽缩小到 $reSizeWidth 高度自适应.不失真
                if (is_file(DIR_IMAGE . $img)) {
                    $height = $reSizeHeight;
                    $gSize  = getimagesize(DIR_IMAGE . $img);
                    if($gSize){
                        $width  = $gSize[0];
                        $height = $gSize[1];
                        $height = $height/$width * $reSizeWidth;
                        $height = (int)$height;
                    }
                    $popup = $this->model_tool_image->resize($img, $reSizeWidth, $height);
                } else {
                    $popup = $this->model_tool_image->resize('no_image.png', $reSizeWidth, $reSizeHeight);
                }
                $query->rows[$i]['popup'] = $popup;
                $query->rows[$i]['keyword'] = $this->getWebsiteUrl() . $row['keyword'];
                if(empty($row['alt'])){
                    $query->rows[$i]['alt'] = $row['name'];
                }
            }
        }
        return [
            "count"=>$count,
            "photowalls"=>$query->rows
        ];

    }


    public function getPhotowallCount(){
        $sql = "select count(photowall_id) 'count' from `".DB_PREFIX."photowall` where `status`=1";
        $query = $this->db->query($sql);
        return $query->row['count'];
    }

    /**
     * 判断是否为图片.
     * @param $file_name
     * @return bool|int
     */
    public function  isImg($file_name)
    {
        $file     = fopen($file_name, "rb");
        $bin      = fread($file, 2);  // 只读2字节

        fclose($file);
        $strInfo  = @unpack("C2chars", $bin);
        $typeCode = intval($strInfo['chars1'].$strInfo['chars2']);

        if($typeCode == 255216 /*jpg*/ || $typeCode == 7173 /*gif*/ || $typeCode == 13780 /*png*/)
        {
            return $typeCode;
        }
        else
        {
            // echo '"仅允许上传jpg/jpeg/gif/png格式的图片！';
            return false;
        }
    }

    public function queryPhotowall($field,$value){
        $sql = 'select * from '.DB_PREFIX.'photowall WHERE '.$field.'=\''.$value.'\'';
        return $this->db->query($sql);
    }


    public function uploadSingle($file_info, $uploader='', $mail='',$comment,$uploadKey){
        $query = $this->queryPhotowall('upload_key',$uploadKey);
        if($query->num_rows==0){
            $ip = $this->getIp();
            $uploadDate = date('Y-m-d H:i:s');
            $user_agent = $_SERVER['HTTP_USER_AGENT'];
            $insertSql = 'INSERT INTO '.DB_PREFIX.'photowall ( `name`, `image`, `sort_order`, `status`, `comment`, `ip`, `country`, `uploader`, `user_agent`, `mail`, `product_ids`, `upload_key`, `upload_date`)  '
                . 'VALUES ( \'\', NULL, 0, 0, \'' . $comment . '\', \''.$ip.'\', \'\', \''.$uploader.'\', \''.$user_agent.'\', \''.$mail.'\', NULL, \''.$uploadKey.'\', \''.$uploadDate.'\')';
            $this->db->query($insertSql);
            $photowallId = $this->db->getLastId();
        }else{
            $photowallId = $query->row['photowall_id'];
        }
        $fileDirPath = $this->upload_photowall_dir . '/'.$uploadKey ;


        $suffix = '';
        if(preg_match("/^([^.^\/]+)(\.[^.^\/]+)$/",$file_info['name'],$match)){
            $suffix = $match[2];
        }
        $bef = '1';
        $filePath = $fileDirPath . '/' .$bef . $suffix;


        $max_rename = 51;
        for($i=0 ;$i<$max_rename;$i++){
            if (file_exists($filePath)){
                $bef = (int)$bef + 1;
                $filePath = $fileDirPath . '/' .$bef . $suffix;
            }else{
                break;
            }
        }
        if($i == $max_rename){
            return false;
        }
        if(!file_exists($fileDirPath)){
            mkdir($fileDirPath,0777,true);
        }
        if(rename( $file_info['tmp_name'] , $filePath)){
            $photowall_image_sql = 'INSERT INTO '.DB_PREFIX.'photowall_image ( `photowall_id`, `image`, `sort_order`, `alt`, `name`)'
                . ' VALUES ( '.$photowallId. ', \''. $filePath  . '\', 0, \'\',\''.$bef . $suffix.'\')';
            $this->db->query($photowall_image_sql);
        }else{
            return false;
        }
        return true;
    }

    private function getIp(){
        if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
            $ip = getenv("HTTP_CLIENT_IP");
        else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
            $ip = getenv("HTTP_X_FORWARDED_FOR");
        else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
            $ip = getenv("REMOTE_ADDR");
        else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
            $ip = $_SERVER['REMOTE_ADDR'];
        else
            $ip = "unknown";
        return $ip;
    }

}