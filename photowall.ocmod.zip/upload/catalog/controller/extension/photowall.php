<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017-09-21
 * Time: 下午 12:23
 */
class ControllerExtensionPhotowall extends Controller
{


    public function index()
    {

        $this->load->model('extension/photowall');

        $this->document->addStyle('catalog/view/javascript/photowall.css');

        $data = [];

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );
        $data['breadcrumbs'][] = array(
            'text' => 'photowall',
            'href' => $this->url->link('extension/photowall')
        );

        $total = 0;
        $page  = ;
        $page
        $photowalls = $this->model_extension_photowall->getPhotowallAndImages([], $total);

        $data['photowalls'] = $photowalls;

        $pagination = new Pagination();
        $pagination->total = $total;
        $pagination->page = $page;
        $pagination->limit = $limit;
        $pagination->url = $this->url->link('extension/extension/blog/blog', $url . '&page={page}');

        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');




        $view = $this->load->view('extension/photowall/list',$data);
        $this->response->setOutput($view);
    }

    public function content()
    {
        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );


        $this->load->model('extension/photowall');

        $request = $this->request;
        $photowall_id = $request->get['photowall_id'];

        $photowall = $this->model_extension_photowall->getPhotowall($photowall_id);

        if($photowall){
            $data['breadcrumbs'][] = array(
                'text' => 'photowall',
                'href' => $this->url->link('extension/photowall')
            );

            $this->document->      setTitle($photowall['meta_title']);
            $this->document->setDescription($photowall['meta_description']);
            $this->document->   setKeywords($photowall['meta_keyword']);
            $data['header'] = $this->load->controller('common/header');
            $data['photowall'] = $photowall;
            $view = $this->load->view('extension/photowall/content',$data);

        }else{

            $data['breadcrumbs'][] = array(
                'text' => $this->language->get('text_error'),
                'href' => $this->url->link('extension/photowall', 'photowall_id=' . $photowall_id)
            );

            $this->document->setTitle($this->language->get('text_error'));

            $data['heading_title'] = $this->language->get('text_error');

            $data['text_error'] = $this->language->get('text_error');

            $data['button_continue'] = $this->language->get('button_continue');

            $data['continue'] = $this->url->link('common/home');

            $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 404 Not Found');


            $view = $this->load->view('error/not_found', $data);
        }


        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');

        $this->response->setOutput($view);

    }

    /**
     * ajax upload image
     * @return string
     */
    public function upload()
    {
        $this->load->language('extension/photowall');
        $request = $this->request;
        if ('POST' == $request->server['REQUEST_METHOD']  && $request->files ) {
            $this->response->addHeader('Content-Type: application/json');
            $json = [
                "data"=>[],
            ];
            $this->load->model('extension/photowall');
            $upload_key =  $this->session->data['photowall_upload_key'];

            $file = current($request->files);
            $file_size = $file['size'][0];
            $file_name = $file['name'][0];
            $file_type = $file['type'][0];
            $file_error_code = $file['error'][0];

            $temp = $file['tmp_name'][0];

            $name    = trim($request->post['name']);
            $mail    = trim($request->post['mail']);
            $comment = htmlentities($request->post['comment']);

            $http_status = 400;
            if ($file_size > 1024 * 1024 * 5 || $file_error_code == 1) { //最大图片为5M
                $json['error'] = $this->language->get('err_upload_size');
            } else if (!$this->model_extension_photowall->isImg($temp)) {
                $json['error'] = $this->language->get('err_upload_type');
            }else if($file_error_code !=0){
                /**
                 *  图片上传错误代码.
                 * @link http://php.net/manual/zh/features.file-upload.errors.php
                 */
                $json['error'] = '';
            } else{
                /**
                 *  防注入
                 */
                $name    = $this->db->escape($name);
                $mail    = $this->db->escape($mail);
                $comment = $this->db->escape($comment);

                $img_info = [
                    'name' => $file_name,
                    'type' => $file_type,
                    'size' => $file_size,
                    'tmp_name' => $temp,
                ];
                if ($this->model_extension_photowall->uploadSingle($img_info, $name, $mail, $comment, $upload_key)) {
                    $this->response->setOutput(json_encode($json));
                    return '';
                }else{
                    $http_status = 500;
                    $json['error'] = $this->language->get('err_upload');
                }
            }

            if ($temp) {
                unlink($temp);
            }
            http_response_code ($http_status);
            $this->response->setOutput(json_encode($json));
            return '';
        }

        $this->document->addScript('catalog/view/javascript/bootstrap-fileimput/js/fileinput.min.js');
        $this->document->addStyle('catalog/view/javascript/bootstrap-fileimput/css/fileinput.min.css');

        $data = [];
        $data['uploadUrl'] = $this->url->link('extension/photowall/upload');
        $breadcrumbs = [];
        $breadcrumbs[] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home')
        );
        $breadcrumbs[] = array(
            'text' => 'photowall',
            'href' => $this->url->link('extension/photowall')
        );
        $breadcrumbs[] = array(
            'text' => 'upload photos',
            'href' => $this->url->link('extension/photowall/upload')
        );
        // 标识同一批上传图片
        $upload_key = uniqid(date('Y-m-d_h-i-s_'));
        $this->session->data['photowall_upload_key'] = $upload_key;

        $data['breadcrumbs'] = $breadcrumbs;
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['column_right'] = $this->load->controller('common/column_right');
        $data['content_top'] = $this->load->controller('common/content_top');
        $data['content_bottom'] = $this->load->controller('common/content_bottom');
        $data['footer'] = $this->load->controller('common/footer');
        $data['header'] = $this->load->controller('common/header');
        $this->response->setOutput($this->load->view('extension/photowall/upload', $data));
    }
}
